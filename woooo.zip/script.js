function sendLove() {
  alert("Thank you! Sending purple love back to you 💜✨");
}


